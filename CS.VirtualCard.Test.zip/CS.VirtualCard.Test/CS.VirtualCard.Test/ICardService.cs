﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS.VirtualCard.Test
{
    public interface ICardService : IPinService
    {
        void WithdrawMoney(VirtualCard virtualCard,Decimal amount);
        void TopupMoney(VirtualCard virtualCard,Decimal amount);
    }
}
