﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace CS.VirtualCard.Test
{
    public class CardService : ICardService
    {
       
        public static readonly object lockobj = new object();
        public void TopupMoney(VirtualCard virtualCard,Decimal amount)
        {
            try
            {
                Monitor.TryEnter(lockobj, TimeSpan.FromMilliseconds(100));
                virtualCard.Balance = virtualCard.Balance + amount;
            }
            finally
            {
                Monitor.Exit(lockobj);
            }

        }

        public void WithdrawMoney(VirtualCard virtualCard,Decimal amount)
        {
            bool isValid= PinValidation(virtualCard.Pin);

            if (isValid == false)
                throw new Exception("Invalid Pin");

            if (virtualCard.Balance < amount)
                throw new Exception("InSufficent balance");
            try
            {
                Monitor.TryEnter(lockobj, TimeSpan.FromMilliseconds(100));
                virtualCard.Balance = virtualCard.Balance - amount;
            }
            finally
            {
                Monitor.Exit(lockobj);
            }
        }

        public bool PinValidation(int pin)
        {
           return pin.Equals(1234) ? true : false;
        }
    }
}
