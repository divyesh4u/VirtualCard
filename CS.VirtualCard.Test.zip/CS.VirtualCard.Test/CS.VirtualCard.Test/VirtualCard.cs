﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS.VirtualCard.Test
{
    public class VirtualCard
    {

        public VirtualCard(Decimal balance, int pin)
        {
            Balance = balance;
            Pin = pin;

        }
        public decimal Balance { get; set; }
        public int Pin { get; set; }

        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;

            if (obj.GetType() != this.GetType())
                return false;

            VirtualCard virtualCard=(VirtualCard)obj;

            return (this.Balance == virtualCard.Balance && this.Pin == virtualCard.Pin);
        }

        public override int GetHashCode()
        {
            var hashcode = 35203328;
            hashcode = hashcode * 1133 + this.Pin.GetHashCode();
            hashcode = hashcode * 1133 + this.Balance.GetHashCode();
            return hashcode;
        }
    }
}
