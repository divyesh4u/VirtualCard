﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CS.VirtualCard.Test;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;

namespace CS.VirtualCard.Test.Tests
{
    [TestClass()]
    public class CardServiceTests
    {
        IUnityContainer unityContainer;
        ICardService cardService;

        [TestInitialize]
        public void Setup()
        {
            unityContainer = new UnityContainer();
            unityContainer.RegisterType<ICardService, CardService>();
            cardService=unityContainer.Resolve<CardService>();

        }

        [TestMethod()]
        [ExpectedException(typeof(Exception), "Invalid Pin")]
        public void InvalidPin()
        {
            VirtualCard card = new VirtualCard(1000, 3456);
            cardService.WithdrawMoney(card, 100);
        }


        [TestMethod()]
        [ExpectedException(typeof(Exception), "InSufficent balance")]
        public void InsufficentMoney()
        {
            VirtualCard card = new VirtualCard(100, 1234);
            cardService.WithdrawMoney(card, 500);
        }

        [TestMethod()]
        public void WithdrawMoneyTest()
        {
            Decimal expectedBalance = 500;
            VirtualCard expectedObj = new VirtualCard(500, 1234);
            VirtualCard card = new VirtualCard(1000, 1234);
            cardService.WithdrawMoney(card, 500);

            Assert.AreEqual(expectedBalance,card.Balance);
            Assert.AreEqual(expectedObj, card);
        }

        [TestMethod()]
        public void ThreadSafeWithdrawTest()
        {
            VirtualCard expectedcard = new VirtualCard(0, 1234);
            VirtualCard actualcard = new VirtualCard(50000, 1234);

            Parallel.For(0, 50000, i => cardService.WithdrawMoney(actualcard, 1));

            Assert.AreEqual<VirtualCard>(expectedcard, actualcard);
        }

        [TestMethod()]
        public void ConcurrencyTest()
        {
            VirtualCard expectedCard = new VirtualCard(0, 1234);
            VirtualCard actualCard = new VirtualCard(50000, 1234);

            VirtualCard expectedCard1 = new VirtualCard(1000, 1234);
            VirtualCard actualCard1 = new VirtualCard(6000, 1234);

            Task task1 = Task.Factory.StartNew(() =>
             {
                 Parallel.For(0, 50000, i => cardService.WithdrawMoney(actualCard, 1));
             });

            Task task2 = Task.Factory.StartNew(() =>
            {
                Parallel.For(0, 5000, i => cardService.WithdrawMoney(actualCard1, 1));
            });

            Task.WaitAll(task1, task2);

            Assert.AreEqual<VirtualCard>(expectedCard, actualCard);
            Assert.AreEqual<VirtualCard>(expectedCard1, actualCard1);

        }

        [TestMethod()]
        public void TopupMoneyTest()
        {
            Decimal expectedBalance = 1000;
            VirtualCard expectedObj = new VirtualCard(1000, 1234);
            VirtualCard card = new VirtualCard(500, 1234);
            cardService.TopupMoney(card, 500);

            Assert.AreEqual(expectedBalance, card.Balance);
            Assert.AreEqual(expectedObj, card);
        }

        [TestMethod()]
        public void ThreadSafeTopUpMoneyTest()
        {
            VirtualCard expectedcard = new VirtualCard(100000, 1234);
            VirtualCard actualcard = new VirtualCard(50000, 1234);

            Parallel.For(0, 50000, i => cardService.TopupMoney(actualcard, 1));

            Assert.AreEqual<VirtualCard>(expectedcard, actualcard);
        }


        [TestMethod()]
        public void ConcurrencyWithdranNTopupTest()
        {
            VirtualCard expectedCard = new VirtualCard(5000, 1234);
            VirtualCard actualCard = new VirtualCard(10000, 1234);

            Task task1 = Task.Factory.StartNew(() =>
            {
                Parallel.For(0, 10000, i => cardService.WithdrawMoney(actualCard, 1));
            });

            Task task2 = Task.Factory.StartNew(() =>
            {
                Parallel.For(0, 5000, i => cardService.TopupMoney(actualCard, 1));
            });

            Task.WaitAll(task1, task2);

            Assert.AreEqual<VirtualCard>(expectedCard, actualCard);
    
        }
    }
}